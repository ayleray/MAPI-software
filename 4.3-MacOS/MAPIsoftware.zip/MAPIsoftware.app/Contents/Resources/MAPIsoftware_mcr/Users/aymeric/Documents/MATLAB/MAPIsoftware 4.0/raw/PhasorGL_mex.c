/*==========================================================
 * phasor_mex.c - Calculate the phasor of a pixel line
 *
 * Inputs:
 * laser angular frequency: w
 * time vector: t
 * 1xN input matrix: data
 *
 * OUTPOUTS:
 * 1xN matrix with first phasor coordinate: g_bin
 * 1xN matrix with second phasor coordinate: s_bin
 *
 * The calling syntax is:
 *
 *        [g_bin,s_bin] = phasor_mex(w, t, data)
 *
 * This is a MEX-file for MATLAB.
 * Copyright 2007-2012 The MathWorks, Inc.
 *
 * by Aymeric LERAY (CNRS, Universit� Bourgogne-Franche-Comt�)
 *
 *========================================================*/

#include "mex.h"
#include <math.h>

/* The computational routine */
void phasor_mex(float w, float *t, float *data, double *g_bin, double *s_bin, mwSize n, mwSize m)
{
    mwSize i,k;
    float temp,temp2,xi[n],weight[n],tautemp;

    /* phasor calculation for one pixel line*/
    for (i=0;i<m;i++){
            
        temp=0;
        temp2=0;
        
        
        if (n==5){
            xi[0]=0.26356031971814091020;
            xi[1]=1.4134030591065167922;
            xi[2]=3.5964257710407220812;
            xi[3]=7.0858100058588375569;
            xi[4]=12.640800844275782659;
            
            weight[0]=0.52175561058280865248;
            weight[1]=0.39866681108317592745;
            weight[2]=0.075942449681707595388;
            weight[3]=0.0036117586799220484545;
            weight[4]=0.000023369972385776227891;
        }
        else if (n==16){
            
            xi[0]=0.087649410478927840360;
            xi[1]= 0.46269632891508083188;
            xi[2]= 1.1410577748312268569;
            xi[3]= 2.1292836450983806163;
            xi[4]=3.4370866338932066452;
            xi[5]=5.0780186145497679129;
            xi[6]=7.0703385350482341304;
            xi[7]=9.4383143363919387839;
            xi[8]=12.214223368866158737;
            xi[9]=15.441527368781617077;
            xi[10]=19.180156856753134855;
            xi[11]=23.515905693991908532;
            xi[12]=28.578729742882140368;
            xi[13]=34.583398702286625815;
            xi[14]=41.940452647688332635;
            xi[15]=51.701160339543318364;
            
            weight[0]=0.20615171495780099433;
            weight[1]=0.33105785495088416599;
            weight[2]=0.26579577764421415260;
            weight[3]=0.13629693429637753998;
            weight[4]=0.047328928694125218978;
            weight[5]=0.011299900080339453231;
            weight[6]=0.0018490709435263108643;
            weight[7]=0.00020427191530827846013;
            weight[8]=0.000014844586873981298771;
            weight[9]=6.8283193308711995644e-7;
            weight[10]=1.8810248410796732139e-8;
            weight[11]=2.8623502429738816196e-10;
            weight[12]=2.1270790332241029674e-12;
            weight[13]=6.2979670025178677872e-15;
            weight[14]=5.0504737000355128204e-18;
            weight[15]=4.1614623703728551904e-22;
        }
        else if (n==7){
            xi[0]=0.19304367656036241384;
            xi[1]=1.0266648953391919503;
            xi[2]=2.5678767449507462069;
            xi[3]=4.9003530845264845681;
            xi[4]=8.1821534445628607911;
            xi[5]=12.734180291797813758;
            xi[6]=19.395727862262540312;
            
            weight[0]=0.40931895170127390213;
            weight[1]=0.42183127786171977993;
            weight[2]=0.14712634865750527840;
            weight[3]=0.020633514468716939866;
            weight[4]=0.0010740101432807455221;
            weight[5]=0.000015865464348564201269;
            weight[6]=3.1703154789955805623e-8;
        }

        
        tautemp = (xi[0]-xi[1])/(logf(data[i+m])-logf(data[i]));

        
        
        for (k=0;k<n-1;k++){
            temp += cosf(w*xi[k]*tautemp)*weight[k];
            temp2 += sinf(w*xi[k]*tautemp)*weight[k];
        }
        g_bin[i]= temp;
        s_bin[i]= temp2;
    }
}

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
    float w;              /* input scalar */
    float *t;
    float *inMatrix;               /* 1xN input matrix */
    int n,m;                   /* size of matrix */
    double *g_bin,*s_bin;              /* output matrix */

    /* check for proper number of arguments */
    if(nrhs!=3) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nrhs","Three inputs required.");
    }
    if(nlhs!=2) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nlhs","Two outputs required.");
    }
    
    /* make sure the input argument is scalar */
    if( !mxIsNumeric(prhs[0]) ||
         mxIsComplex(prhs[0]) ||
         mxGetNumberOfElements(prhs[0])!=1 ) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input w must be a scalar.");
    }
    
    /* make sure the input argument is type single */
    if( !mxIsSingle(prhs[1]) ||
         mxIsComplex(prhs[1])) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notDouble","Input t must be type single.");
    }
    
    /* make sure the input argument is type single */
    if( !mxIsSingle(prhs[2]) ||
         mxIsComplex(prhs[2])) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notDouble","Input data must be type single.");
    }
    /* check that number of rows in second input argument is 1 */
    //if(mxGetM(prhs[2])!=1) {
    //    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notRowVector","Input data must be a row vector.");
    //}
   
    
    /* get the value of the scalar input  */
    w = mxGetScalar(prhs[0]);
    t = mxGetData(prhs[1]);

    /* create a pointer to the real data in the input matrix  */
    //inMatrix = mxGetPr(prhs[2]);
    inMatrix = mxGetData(prhs[2]);

    /* get dimensions of the input matrix (number of columns) */
    n = mxGetN(prhs[2]);
    /* get dimensions of the input matrix (number of rows) */
    m = mxGetM(prhs[2]);

    /* create the output matrix */
    plhs[0] = mxCreateDoubleMatrix(1,(mwSize)m,mxREAL);
    //plhs[0] = mxCreateNumericMatrix(1,(mwSize)nb_pt, mxSINGLE_CLASS, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(1,(mwSize)m,mxREAL);
    //plhs[1] = mxCreateNumericMatrix(1,(mwSize)nb_pt, mxSINGLE_CLASS,mxREAL);

    /* get a pointer to the real data in the output matrix */
    g_bin =  mxGetPr(plhs[0]);
    //g_bin = mxGetData(plhs[0]);
    //s_bin = mxGetData(plhs[1]);
    s_bin = mxGetPr(plhs[1]);

    /* call the computational routine */
    phasor_mex(w,t,inMatrix,g_bin,s_bin,(mwSize)n,(mwSize)m);
}
