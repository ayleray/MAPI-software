/*==========================================================
 * phasor_mex.c - Calculate the phasor of a pixel line
 *
 * Inputs:
 * laser angular frequency: w
 * time vector: t
 * 1xN input matrix: data
 *
 * OUTPOUTS:
 * 1xN matrix with first phasor coordinate: g_bin
 * 1xN matrix with second phasor coordinate: s_bin
 *
 * The calling syntax is:
 *
 *        [g_bin,s_bin] = phasor_mex(w, t, data)
 *
 * This is a MEX-file for MATLAB.
 * Copyright 2007-2012 The MathWorks, Inc.
 *
 * by Aymeric LERAY (CNRS, Universit� Bourgogne-Franche-Comt�)
 *
 *========================================================*/

#include "mex.h"
#include <math.h>

/* The computational routine */
void phasor_mex(float w, float *t, float *data, double *g_bin, double *s_bin, double *tau_int, double *tau_mean, mwSize n, mwSize m)
{
    mwSize i,k;
    float temp,temp2,temp3,temp4;

    /* phasor calculation for one pixel line*/
    for (i=0;i<m;i++){
            
        temp=0;
        temp2=0;
        temp3=0;
        temp4=0;
        
        /* trapeze for one decay */
        for (k=0;k<n-1;k++){
            temp += (data[i+k*m]*cosf(t[k]*w)+data[i+(k+1)*m]*cosf(t[k+1]*w))*(t[k+1]-t[k]);
            temp2 += (data[i+k*m]*sinf(t[k]*w)+data[i+(k+1)*m]*sinf(t[k+1]*w))*(t[k+1]-t[k]);
            temp3 += (data[i+k*m]+data[i+(k+1)*m])*(t[k+1]-t[k]);
            temp4 += (data[i+k*m]*t[k]+data[i+(k+1)*m]*t[k+1])*(t[k+1]-t[k]);
        }
        
        g_bin[i]= temp / temp3;
        s_bin[i]= temp2 / temp3;
        
        tau_int[i] = temp3/2.0 * 1e9 / data[i];
        tau_mean[i] = temp4 * 1e9 / temp3;
    }
}

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
    float w;              /* input scalar */
    float *t;
    float *inMatrix;               /* 1xN input matrix */
    int n,m;                   /* size of matrix */
    double *g_bin,*s_bin;              /* output matrix */
    double *tau_mean,*tau_int;              /* output matrix */

    /* check for proper number of arguments */
    if(nrhs!=3) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nrhs","Three inputs required.");
    }
    if(nlhs!=4) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nlhs","Four outputs required.");
    }
    
    /* make sure the input argument is scalar */
    if( !mxIsNumeric(prhs[0]) ||
         mxIsComplex(prhs[0]) ||
         mxGetNumberOfElements(prhs[0])!=1 ) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input w must be a scalar.");
    }
    
    /* make sure the input argument is type single */
    if( !mxIsSingle(prhs[1]) ||
         mxIsComplex(prhs[1])) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notDouble","Input t must be type single.");
    }
    
    /* make sure the input argument is type single */
    if( !mxIsSingle(prhs[2]) ||
         mxIsComplex(prhs[2])) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notDouble","Input data must be type single.");
    }
    /* check that number of rows in second input argument is 1 */
    //if(mxGetM(prhs[2])!=1) {
    //    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notRowVector","Input data must be a row vector.");
    //}
   
    
    /* get the value of the scalar input  */
    w = mxGetScalar(prhs[0]);
    t = mxGetData(prhs[1]);

    /* create a pointer to the real data in the input matrix  */
    //inMatrix = mxGetPr(prhs[2]);
    inMatrix = mxGetData(prhs[2]);

    /* get dimensions of the input matrix (number of columns) */
    n = mxGetN(prhs[2]);
    /* get dimensions of the input matrix (number of rows) */
    m = mxGetM(prhs[2]);

    /* create the output matrix */
    plhs[0] = mxCreateDoubleMatrix(1,(mwSize)m,mxREAL);
    //plhs[0] = mxCreateNumericMatrix(1,(mwSize)nb_pt, mxSINGLE_CLASS, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(1,(mwSize)m,mxREAL);
    //plhs[1] = mxCreateNumericMatrix(1,(mwSize)nb_pt, mxSINGLE_CLASS,mxREAL);
    plhs[2] = mxCreateDoubleMatrix(1,(mwSize)m,mxREAL);
    plhs[3] = mxCreateDoubleMatrix(1,(mwSize)m,mxREAL);

    /* get a pointer to the real data in the output matrix */
    g_bin =  mxGetPr(plhs[0]);
    s_bin = mxGetPr(plhs[1]);
    tau_int =  mxGetPr(plhs[2]);
    tau_mean = mxGetPr(plhs[3]);

    /* call the computational routine */
    phasor_mex(w,t,inMatrix,g_bin,s_bin,tau_int,tau_mean,(mwSize)n,(mwSize)m);
}
