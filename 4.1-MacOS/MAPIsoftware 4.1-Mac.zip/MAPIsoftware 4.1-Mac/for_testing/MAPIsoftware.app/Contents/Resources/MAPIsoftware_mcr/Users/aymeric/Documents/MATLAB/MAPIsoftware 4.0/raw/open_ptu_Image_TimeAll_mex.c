/*==========================================================
 * open_ptu_mex.c - open ptu file from PicoQuant
 *
 * open the ptu file (file_in)
 * Start opening at offset
 * write in 1xN matrix (raw) with N=StopAfter/bin (single precision)
 * number of events: NbRec
 * temporal resolution (millisecond)/temporal bin (ms): GlobResBin
 * total time (millisecond)/temporal bin (ms): StopAfterBin
 *
 * The calling syntax is:
 *
 *		raw=open_ptu_mex(offset,StopAfter,GlobRes,NbRec,file_in);
 *
 * This is a MEX-file for MATLAB.
 * Copyright 2007-2012 The MathWorks, Inc.
 * 
 * by Aymeric LERAY (CNRS, Universit� Bourgogne-Franche-Comt�)
 *
 *========================================================*/

#include "mex.h"
#include <stdio.h>
#include <stdlib.h>
#include  <stddef.h>
#include  <time.h>
//#include    <inttypes.h>
#include    <math.h>


/* The computational routine */
void open_ptu_Image_mex(double offset, mwSize PixX, mwSize PixY, mwSize MaxTime, double binX, double GlobRes, double NbRec,mwSize chStart,mwSize chStop,char *file_in, float *raw, float *raw2,float *raw3,float *raw4)
{
    mwSize i;
    FILE *fid;
    fid=fopen(file_in, "rb+");
    const int T3WRAPAROUND = 65536;
               
    union
    {
      unsigned int allbits;
      struct
      {
      unsigned numsync  :16;
      unsigned dtime    :12;
      unsigned channel  :4;
      } bits;
      struct
      {
      unsigned numsync  :16;
      unsigned markers  :12;
      unsigned channel  :4;
      } special;
    } Record;
    
    int start_image=0, iX=0, iY=0,acq_line=0,nPix;
    unsigned long long int truensync=0, oflcorrection = 0;
    double time,start_line,stop_line;
    double timeX;
    int cnt_image=-1;
    
    fseek(fid, offset, SEEK_SET);
    
    for (i=0; i<NbRec; i++) {
        
        fread(&Record.allbits, 1, sizeof(Record.allbits) ,fid);

        if(Record.bits.channel==0xF){ //this means we have a special record
        
            if(Record.special.markers==0) //not a marker means overflow
            {
              oflcorrection += T3WRAPAROUND; // unwrap the time tag overflow
            }
            else {
              truensync = oflcorrection + Record.bits.numsync;
                if (Record.special.markers==1){
                    start_line=truensync * GlobRes*1e9;
                    acq_line=1;
                }
                if (Record.special.markers==2){
                    stop_line=truensync * GlobRes*1e9;
                    acq_line=0;
                    iY++;
                }
                if (Record.special.markers==4){
                    cnt_image++;
                    start_image=1;
                    iY=0;
                }
            }
        }
        else {//regular input channel
            truensync = oflcorrection + Record.bits.numsync;
            
            if (acq_line==1 && start_image==1){
                time=(truensync * GlobRes*1e9);
                iX=(time-start_line)/binX/1000;
                nPix=iX+PixX*iY;

                // time in microsecond
                timeX=(time-(iX*binX*1000+start_line)+binX*1000*cnt_image)/1000;
                
                if (nPix>PixX*PixY){
                    nPix=PixX*PixY+1;
                }
                if (Record.bits.channel==1 && Record.bits.dtime>=chStart-1 && Record.bits.dtime<=chStop-1)
                {
                    raw[(int)(timeX/binX+nPix*MaxTime)]++;
                    raw2[(int)(timeX/binX+nPix*MaxTime)]+=Record.bits.dtime-(chStart-1);
                }
                if (Record.bits.channel==2 && Record.bits.dtime>=chStart-1 && Record.bits.dtime<=chStop-1)
                {
                    raw3[(int)(timeX/binX+nPix*MaxTime)]++;
                    raw4[(int)(timeX/binX+nPix*MaxTime)]+=Record.bits.dtime-(chStart-1);
                }
            }
        }
    }
    fclose(fid);
}

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
    double GlobRes, offset, NbRec,binX;              /* input scalar */
    int PixX,PixY, MaxTime,chStart,chStop;
    char *inFile;               /* 1xN input matrix */
    float *outMatrix,*outMatrix2,*outMatrix3,*outMatrix4;              /* output matrix */

    /* check for proper number of arguments */
    if(nrhs!=10) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nrhs","Ten inputs required.");
    }
    if(nlhs!=4) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nlhs","Four outputs required.");
    }
        
    /* get the value of the scalar input  */
    offset = mxGetScalar(prhs[0]);
    PixX = mxGetScalar(prhs[1]);
    PixY = mxGetScalar(prhs[2]);
    MaxTime = mxGetScalar(prhs[3]);
    binX = mxGetScalar(prhs[4]);
    GlobRes = mxGetScalar(prhs[5]);
    NbRec = mxGetScalar(prhs[6]);
    chStart = mxGetScalar(prhs[7]);
    chStop = mxGetScalar(prhs[8]);

    /* create a pointer to the real data in the input matrix  */
    inFile = mxArrayToString(prhs[9]);

    /* create the output matrix */
    plhs[0] = mxCreateNumericMatrix(MaxTime,PixX*PixY+1,mxSINGLE_CLASS,mxREAL);
    plhs[1] = mxCreateNumericMatrix(MaxTime,PixX*PixY+1,mxSINGLE_CLASS,mxREAL);
    plhs[2] = mxCreateNumericMatrix(MaxTime,PixX*PixY+1,mxSINGLE_CLASS,mxREAL);
    plhs[3] = mxCreateNumericMatrix(MaxTime,PixX*PixY+1,mxSINGLE_CLASS,mxREAL);

    /* get a pointer to the real data in the output matrix */
    outMatrix = mxGetData(plhs[0]);
    outMatrix2 = mxGetData(plhs[1]);
    outMatrix3 = mxGetData(plhs[2]);
    outMatrix4 = mxGetData(plhs[3]);

    /* call the computational routine */
    open_ptu_Image_mex(offset,PixX,PixY,MaxTime,binX,GlobRes,NbRec,chStart,chStop,inFile,outMatrix,outMatrix2,outMatrix3,outMatrix4);
}
