/*==========================================================
 * open_ptu_mex.c - open ptu file from PicoQuant
 *
 * open the ptu file (file_in)
 * Start opening at offset
 * write in 1xN matrix (raw) with N=StopAfter/bin (single precision)
 * number of events: NbRec
 * temporal resolution (millisecond)/temporal bin (ms): GlobResBin
 * total time (millisecond)/temporal bin (ms): StopAfterBin
 *
 * The calling syntax is:
 *
 *		raw=open_ptu_mex(offset,StopAfter,GlobRes,NbRec,file_in);
 *
 * This is a MEX-file for MATLAB.
 * Copyright 2007-2012 The MathWorks, Inc.
 * 
 * by Aymeric LERAY (CNRS, Universit� Bourgogne-Franche-Comt�)
 *
 *========================================================*/

#include "mex.h"
#include <stdio.h>
#include <stdlib.h>
#include  <stddef.h>
#include  <time.h>
//#include    <inttypes.h>
#include    <math.h>


/* The computational routine */
void open_ptu_Image_mex(double offset, mwSize PixX, mwSize PixY, mwSize TotChan, double GlobRes, double NbRec, char *file_in, float *raw, float *raw2)
{
    mwSize i,j;
    FILE *fid;
    fid=fopen(file_in, "rb+");
    const int T3WRAPAROUND = 1024;
    
    union {
      unsigned int allbits;
      struct  {
        unsigned nsync    :10;  // numer of sync period
        unsigned dtime    :15;    // delay from last sync in units of chosen resolution
        unsigned channel  :6;
        unsigned special  :1;
      } bits;
    } T3Rec;
    
    int start_image=0, iX=0, iY=0,acq_line=0,nPix;
    unsigned long long int truensync=0, oflcorrection = 0;
    double time,start_line,stop_line;
    int binX;
    
    fseek(fid, offset, SEEK_SET);
    
    for (i=0; i<NbRec; i++) {
        
        fread(&T3Rec.allbits, 1, sizeof(T3Rec.allbits) ,fid);

        if(T3Rec.bits.special==1){ //this means we have a special record
        
            if(T3Rec.bits.channel==0x3F) //overflow
            {
              oflcorrection += T3WRAPAROUND * T3Rec.bits.nsync;
            }
            if((T3Rec.bits.channel>=1)&&(T3Rec.bits.channel<=15)) //markers
            {
              truensync = oflcorrection + T3Rec.bits.nsync;
                if (T3Rec.bits.channel==1){
                    start_line=truensync * GlobRes*1e9;
                    acq_line=1;
                }
                if (T3Rec.bits.channel==2){
                    stop_line=truensync * GlobRes*1e9;
                    binX=(stop_line-start_line)/(PixX-1);
                    acq_line=0;
                    iY++;
                }
                if (T3Rec.bits.channel==4){
                    start_image=1;
                    iY=0;
                }
            }
        }
        else {//regular input channel
            truensync = oflcorrection + T3Rec.bits.nsync;
            
            if (acq_line==1 && start_image==1){
                time=(truensync * GlobRes*1e9);
                iX=(time-start_line)/binX;
                nPix=iX+PixX*iY;
                if (nPix>PixX*PixY){
                    nPix=PixX*PixY+1;
                }
                if (T3Rec.bits.channel==1)
                    raw[T3Rec.bits.dtime+nPix*TotChan]++;
                if (T3Rec.bits.channel==2)
                    raw2[T3Rec.bits.dtime+nPix*TotChan]++;
            }
        }
    }
    fclose(fid);
}

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
    double GlobRes, offset, NbRec;              /* input scalar */
    int PixX,PixY, TotChan;
    char *inFile;               /* 1xN input matrix */
    float *outMatrix,*outMatrix2;              /* output matrix */

    /* check for proper number of arguments */
    if(nrhs!=7) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nrhs","Seven inputs required.");
    }
    if(nlhs!=2) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nlhs","Two outputs required.");
    }
        
    /* get the value of the scalar input  */
    offset = mxGetScalar(prhs[0]);
    PixX = mxGetScalar(prhs[1]);
    PixY = mxGetScalar(prhs[2]);
    TotChan = mxGetScalar(prhs[3]);
    GlobRes = mxGetScalar(prhs[4]);
    NbRec = mxGetScalar(prhs[5]);

    /* create a pointer to the real data in the input matrix  */
    inFile = mxArrayToString(prhs[6]);

    /* create the output matrix */
    plhs[0] = mxCreateNumericMatrix(TotChan,PixX*PixY+1,mxSINGLE_CLASS,mxREAL);
    plhs[1] = mxCreateNumericMatrix(TotChan,PixX*PixY+1,mxSINGLE_CLASS,mxREAL);

    /* get a pointer to the real data in the output matrix */
    outMatrix = mxGetData(plhs[0]);
    outMatrix2 = mxGetData(plhs[1]);

    /* call the computational routine */
    open_ptu_Image_mex(offset,PixX,PixY,TotChan,GlobRes,NbRec,inFile,outMatrix,outMatrix2);
}
