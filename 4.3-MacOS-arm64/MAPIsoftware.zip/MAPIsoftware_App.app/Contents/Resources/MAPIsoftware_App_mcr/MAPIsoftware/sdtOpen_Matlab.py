#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 22 09:31:27 2024

@author: aymeric
"""


import io
import zipfile

fh=open(file, 'rb')
fh.seek(data_offs)
bio = io.BytesIO(fh.read(next_block_offs - data_offs))
with zipfile.ZipFile(bio) as zf:
    databytes = zf.read(zf.filelist[0].filename)  # data_block

fh.close()